package cts.sandulescu.razvan.g1086.pattern.state.clase;


public class StareConfirmata implements ICerereStudent {
    @Override
    public void confirmare() {
        System.out.println("Cerere primita");
    }

    @Override
    public void verificare() {

    }

    @Override
    public void avizareDecanat() {

    }

    @Override
    public void respingere() {

    }
}
