package cts.sandulescu.razvan.g1086.pattern.state.clase;

public interface ICerereStudent {
    public void confirmare();

    public void verificare();

    public void avizareDecanat();

    public void respingere();
}