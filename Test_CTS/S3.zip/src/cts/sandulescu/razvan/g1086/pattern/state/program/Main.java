package cts.sandulescu.razvan.g1086.pattern.state.program;

import cts.sandulescu.razvan.g1086.pattern.state.clase.Cerere;

public class Main {
    public static void main(String[] args) {
        Cerere cerere = new Cerere(15, "");
        cerere.verificare();

        // NU MAI AM TIMP SA FAC DEBUG :(
    }
}
