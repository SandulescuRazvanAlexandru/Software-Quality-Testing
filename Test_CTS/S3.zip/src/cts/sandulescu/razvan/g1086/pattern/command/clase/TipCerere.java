package cts.sandulescu.razvan.g1086.pattern.command.clase;

public enum TipCerere {
    NORMALA, URGENTA;
}