package cts.sandulescu.razvan.g1086.pattern.command.clase;

public interface IProcesatorCerere {
    public void procesareCerere(TipCerere tip, String denumire);
}