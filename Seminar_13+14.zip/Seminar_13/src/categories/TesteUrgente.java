package categories;

public interface TesteUrgente {
}
