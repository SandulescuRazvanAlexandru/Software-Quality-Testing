package categories;

public interface TesteRight {
}
